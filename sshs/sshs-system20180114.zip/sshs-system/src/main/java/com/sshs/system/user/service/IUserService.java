package com.sshs.system.user.service;

import com.sshs.core.base.service.IBaseService;
import com.sshs.system.user.model.User;

 /** 
 * 系统管理->系统管理-用户表service接口
 * @author Suny
 * @date 2018/01/09
 */
public interface IUserService extends IBaseService<User> {
}

