package com.sshs.system.menu.service;

import com.sshs.core.base.service.IBaseService;
import com.sshs.system.menu.model.Menu;

 /** 
 * 系统管理->系统管理-菜单表service接口
 * @author Suny
 * @date 2017/12/24
 */
public interface IMenuService extends IBaseService<Menu> {
}

