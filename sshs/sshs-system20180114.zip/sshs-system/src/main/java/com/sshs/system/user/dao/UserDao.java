package com.sshs.system.user.dao;

import com.sshs.system.user.model.User;

import tk.mybatis.mapper.common.Mapper;

 /** 
 * 系统管理->系统管理-用户表dao接口类
 * @author Suny
 * @date 2018/01/09
 */
public interface UserDao extends Mapper<User> {
}