package com.sshs.system.menu.dao;

import com.sshs.system.menu.model.Menu;

import tk.mybatis.mapper.common.Mapper;

 /** 
 * 系统管理->系统管理-菜单表dao接口类
 * @author Suny
 * @date 2017/12/24
 */
public interface MenuDao extends Mapper<Menu> {
}