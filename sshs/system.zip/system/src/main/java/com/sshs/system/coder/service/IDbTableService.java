package com.sshs.system.coder.service;

import com.sshs.core.base.service.IBaseService;
import com.sshs.system.coder.model.DbTable;

/**
 * 类名称：代码生成器接口类 
 * @author Suny
 * @date 2017年10月24日
 * 
 * @version
 */
public interface IDbTableService extends IBaseService<DbTable> {

}
