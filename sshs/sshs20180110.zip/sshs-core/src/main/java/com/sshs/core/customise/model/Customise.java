package com.sshs.core.customise.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.ibatis.type.Alias;

/**
 * 自定义查询
 * 
 * @author Suny
 * @date 2017-12-10
 */
@Alias("Customise")
@Table(name = "CORE_CUSTOMISE_QUERY")
public class Customise implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(generator = "UUID")
	private String customiseId;
	private String userCode;

	private String orgCode;
	private String pageId;
	private String customiseName;

	private String fieldContents;

	private String fieldAddons;

	private String crtUserCode;

	private String crtOrgCode;
	private Date crtDate;
	private String updUserCode;
	private String updOrgCode;
	private Date updDate;

	public String getCustomiseId() {
		return customiseId;
	}

	public void setCustomiseId(String customiseId) {
		this.customiseId = customiseId;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}

	public String getCustomiseName() {
		return customiseName;
	}

	public void setCustomiseName(String customiseName) {
		this.customiseName = customiseName;
	}

	public String getFieldContents() {
		return fieldContents;
	}

	public void setFieldContents(String fieldContents) {
		this.fieldContents = fieldContents;
	}

	public String getFieldAddons() {
		return fieldAddons;
	}

	public void setFieldAddons(String fieldAddons) {
		this.fieldAddons = fieldAddons;
	}

	public String getCrtUserCode() {
		return crtUserCode;
	}

	public void setCrtUserCode(String crtUserCode) {
		this.crtUserCode = crtUserCode;
	}

	public String getCrtOrgCode() {
		return crtOrgCode;
	}

	public void setCrtOrgCode(String crtOrgCode) {
		this.crtOrgCode = crtOrgCode;
	}

	public Date getCrtDate() {
		return crtDate;
	}

	public void setCrtDate(Date crtDate) {
		this.crtDate = crtDate;
	}

	public String getUpdUserCode() {
		return updUserCode;
	}

	public void setUpdUserCode(String updUserCode) {
		this.updUserCode = updUserCode;
	}

	public String getUpdOrgCode() {
		return updOrgCode;
	}

	public void setUpdOrgCode(String updOrgCode) {
		this.updOrgCode = updOrgCode;
	}

	public Date getUpdDate() {
		return updDate;
	}

	public void setUpdDate(Date updDate) {
		this.updDate = updDate;
	}

}
